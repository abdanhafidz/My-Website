const home = function(){
    return `
    <h2 align="center">Hi It's Main Page Of AdanJS Framework Glad To See You</h2>
<p align="center">Bleng Bleng Hello There! {-----*----} </p>
    
<a href="test">Test1</a>
<a href="test2">Test1</a>
    `;
}

export default home;
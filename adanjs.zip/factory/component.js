class Inning
{
   main(tgt,obj){
    $(tgt).html(obj);
}
}

export default Inning;
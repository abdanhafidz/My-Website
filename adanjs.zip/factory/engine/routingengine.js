import obj from  "../obj.js";

const ob = new obj;
const ROUTEADD = function(mdl,act){
   var modul = ob.getMdl();
 
   if(modul==mdl){
$('#keren').html(act);
       }else{
           return false;
       }

    

   
     
}


export default ROUTEADD;
//main inning
import home from  "../../modules/home.js";
import Inning from  "../component.js";
import obj from  "../obj.js";

const ob = new obj;
const inning = new Inning;
class Route {
MainRoute(mdl){

    switch(mdl){
        case "test":
            inning.main('#keren','hi');
            break;


            case "":
               inning.main('#keren',home);
                break;

                default:
                    inning.main('#keren','404 - Page Not Found');
                break;

    };
    
    }
constructor(){
    const mdl = ob.getMdl();
    this.MainRoute(mdl);

}
  
}

export default Route;
import Route from  "../engine/router.js";
const Router = new Route;
class MainComplement {
explode(a,i){
    var value = a.split(i);
    return value;
    
    }
   
aClick(){
  
        $('a').click(function(){
            $('a').attr('link','false');
            $(this).attr('link','true');
                    event.preventDefault();
  var target = $('a[link=true]').attr("href");
          
 history.pushState({urlPath:target},"",target);
Router.MainRoute(target);
    });

 
}

}

   export default MainComplement;
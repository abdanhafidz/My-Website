import MainComplement from  "../engine/complement.js";
import Route from  "../engine/router.js";


const Complement = new MainComplement;
const Router  = new Route;

Complement.aClick();

var goingBack = window.tabs.goBack();
goingBack.then(history.go(-1), console.log("Error Going Back"));
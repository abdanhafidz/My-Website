class obj {


explode(a,i){
    var value = a.split(i);
    return value;
    
    }
   
GETURL(){
    var URL = document.URL;
    return URL;
}

 explink(url,idx){

    var idt = idx+3;
    var thy = ""+url+"";
    var exp = this.explode(thy,'/');
    var val = exp[idt];
    return val;
}

getMdl(url=document.location){
   var modul = this.explink(url,1);
    return modul;
}

getAct(url=document.location){
    var modul = this.explink(url,2);
    return modul;
}

getData(url=document.location){
    var modul = this.explink(url,3);
    return modul;
}

};

export default obj;
